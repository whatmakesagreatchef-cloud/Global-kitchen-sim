// Starter pack: implement loader + UI here.
