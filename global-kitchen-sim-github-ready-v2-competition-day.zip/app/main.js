// Global Kitchen Sim — browser-only MVP (no APIs, no build tools)
// v2 adds: Competition Day simulation (formats + profiles + rubric + route bias + flags)

const ROUTES = ["AU", "JP", "FR", "US"];

const el = (id) => document.getElementById(id);
const routesEl = el("routes");
const stateKvEl = el("stateKv");
const flagsOutEl = el("flagsOut");
const missionMetaEl = el("missionMeta");
const missionIntroEl = el("missionIntro");
const missionChoicesEl = el("missionChoices");
const resultBoxEl = el("resultBox");
const dataOutEl = el("dataOut");

// Competition UI (optional elements exist in v2 HTML)
const teamSizeEl = el("teamSize");
const compSelectEl = el("compSelect");
const btnSimulateEl = el("btnSimulate");
const btnRefreshCompsEl = el("btnRefreshComps");
const compOutEl = el("compOut");
const compSummaryEl = el("compSummary");

const btnReset = el("btnReset");
const btnSeason = el("btnSeason");
const btnCatalog = el("btnCatalog");
const btnRoles = el("btnRoles");
const btnTraining = el("btnTraining");

function createButton(label, onClick, cls="") {
  const b = document.createElement("button");
  b.textContent = label;
  if (cls) b.className = cls;
  b.addEventListener("click", onClick);
  return b;
}

async function loadJSON(path) {
  const res = await fetch(path, { cache: "no-store" });
  if (!res.ok) throw new Error(`Failed to load ${path} (${res.status})`);
  return res.json();
}

// ---------------------------
// State + helpers
// ---------------------------
function defaultState() {
  return {
    routeId: "AU",
    week: 1,
    completedMissions: [],
    flags: new Set(),
    team: {
      reputation: 10,
      budget: 300,
      morale: 50,
      cohesion: 45,
      fatigue: 0,
      available_hours: 8,
      risk: 0,
      workflow_bonus: 0,
      readiness: 0
    },
    // lightweight roster placeholder (MVP)
    team_size: 4
  };
}

function getByPath(obj, path) {
  const parts = path.split(".");
  let cur = obj;
  for (const p of parts) {
    if (cur == null) return undefined;
    cur = cur[p];
  }
  return cur;
}

function setByPath(obj, path, value) {
  const parts = path.split(".");
  let cur = obj;
  for (let i = 0; i < parts.length - 1; i++) {
    const p = parts[i];
    if (!(p in cur)) cur[p] = {};
    cur = cur[p];
  }
  cur[parts[parts.length - 1]] = value;
}

function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }

function renderState(state) {
  const kv = [
    ["Route", state.routeId],
    ["Week", String(state.week)],
    ["Team Size", String(state.team_size)],
    ["Reputation", state.team.reputation],
    ["Budget", `$${state.team.budget}`],
    ["Morale", state.team.morale],
    ["Cohesion", state.team.cohesion],
    ["Fatigue", state.team.fatigue],
    ["Available Hours", state.team.available_hours],
    ["Risk", state.team.risk],
    ["Workflow Bonus", state.team.workflow_bonus],
    ["Readiness", state.team.readiness],
    ["Completed Missions", state.completedMissions.length]
  ];
  stateKvEl.innerHTML = "";
  for (const [k,v] of kv) {
    const d = document.createElement("div");
    d.innerHTML = `<div class="k">${escapeHtml(k)}</div><div class="v">${escapeHtml(v)}</div>`;
    stateKvEl.appendChild(d);
  }

  const flags = Array.from(state.flags).sort();
  flagsOutEl.textContent = flags.length ? flags.join("\n") : "(none)";
}

function showResult(kind, text) {
  resultBoxEl.classList.remove("good","bad");
  if (kind === "good") resultBoxEl.classList.add("good");
  if (kind === "bad") resultBoxEl.classList.add("bad");
  resultBoxEl.textContent = text;
}

function showComp(kind, text, breakdownObj=null) {
  if (!compSummaryEl) return;
  compSummaryEl.classList.remove("good","bad");
  if (kind === "good") compSummaryEl.classList.add("good");
  if (kind === "bad") compSummaryEl.classList.add("bad");
  compSummaryEl.textContent = text || "";
  if (compOutEl && breakdownObj) compOutEl.textContent = JSON.stringify(breakdownObj, null, 2);
}

function hasAllFlags(state, flagsAll=[]) {
  return flagsAll.every(f => state.flags.has(f));
}
function hasAnyFlags(state, flagsAny=[]) {
  return flagsAny.some(f => state.flags.has(f));
}
function hasNoneFlags(state, flagsNone=[]) {
  return flagsNone.every(f => !state.flags.has(f));
}

// ---------------------------
// Effects engine (MVP)
/// Supports:
/// - {op:"inc", path:"team.reputation", value:n}
/// - {op:"set_flag", value:"FLAG_X"}
/// - {op:"clear_flag", value:"FLAG_X"}
/// - {op:"set", path:"team.morale", value:n}
/// You can extend with assign_role / swap_roles later.
// ---------------------------
function applyEffect(state, eff) {
  if (!eff || !eff.op) return;

  if (eff.op === "inc") {
    const cur = Number(getByPath(state, eff.path) ?? 0);
    setByPath(state, eff.path, cur + Number(eff.value ?? 0));
    // simple clamps for common stats
    if (eff.path === "team.morale") state.team.morale = clamp(state.team.morale, 0, 100);
    if (eff.path === "team.cohesion") state.team.cohesion = clamp(state.team.cohesion, 0, 100);
    if (eff.path === "team.fatigue") state.team.fatigue = clamp(state.team.fatigue, 0, 100);
  }

  if (eff.op === "set") {
    setByPath(state, eff.path, eff.value);
  }

  if (eff.op === "set_flag") {
    state.flags.add(eff.value);
  }

  if (eff.op === "clear_flag") {
    state.flags.delete(eff.value);
  }
}

function applyOutcome(state, outcome) {
  if (!outcome) return;
  const effects = outcome.effects || [];
  for (const e of effects) applyEffect(state, e);

  // Support legacy "set_flags" array
  if (Array.isArray(outcome.set_flags)) {
    for (const f of outcome.set_flags) state.flags.add(f);
  }
}

// ---------------------------
// Mission runner
// ---------------------------
function isMissionAvailable(state, mission) {
  const req = mission.requirements || {};
  const minRep = req.min_reputation ?? 0;
  const okFlags = hasAllFlags(state, req.flags_all || [])
               && hasNoneFlags(state, req.flags_none || []);
  const anyOk = !req.requires_flag_any || hasAnyFlags(state, req.requires_flag_any);
  return okFlags && anyOk && (state.team.reputation >= minRep) && (mission.week <= state.week);
}

function computeCheck(state, check) {
  const statName = check.stat || "team.reputation";
  const statVal = Number(getByPath(state, statName) ?? 0);
  const difficulty = Number(check.difficulty ?? 10);
  const roll = Math.floor(Math.random() * 20) + 1; // 1..20
  const total = statVal + roll;
  return { statName, statVal, difficulty, roll, total, success: total >= difficulty };
}

function renderMission(state, mission, onDone) {
  missionMetaEl.textContent = `${mission.chapter} • Week ${mission.week} • ${mission.id}`;
  missionIntroEl.innerHTML = (mission.intro || []).map(p => `<p>${escapeHtml(p)}</p>`).join("");
  missionChoicesEl.innerHTML = "";

  if (!mission.choices || mission.choices.length === 0) {
    missionChoicesEl.innerHTML = "<p class='hint'>(No choices in this mission)</p>";
    return;
  }

  for (const choice of mission.choices) {
    const card = document.createElement("div");
    card.className = "choice";
    const check = (choice.checks && choice.checks[0]) ? choice.checks[0] : null;

    const checkText = check
      ? `Check: ${check.stat} vs ${check.difficulty} (roll d20)`
      : "Check: none";

    card.innerHTML = `
      <div class="label">${escapeHtml(choice.label || choice.id)}</div>
      <div class="check">${escapeHtml(checkText)}</div>
    `;

    const act = document.createElement("div");
    act.className = "act";
    const btn = createButton("Choose", async () => {
      let success = true;
      let detail = "";
      if (check) {
        const c = computeCheck(state, check);
        success = c.success;
        detail = `Roll ${c.roll} + ${c.statName}(${c.statVal}) = ${c.total} vs ${c.difficulty}`;
      }

      const outcome = success ? choice.outcomes?.success : choice.outcomes?.fail;
      applyOutcome(state, outcome);

      // Mark mission complete and advance week (simple loop)
      state.completedMissions.push(mission.id);
      state.week = Math.max(state.week, mission.week + 1);

      const text = (outcome?.text || (success ? "Success." : "Fail.")) + (detail ? `\n${detail}` : "");
      showResult(success ? "good" : "bad", text);
      renderState(state);
      refreshCompetitionList(); // missions can change flags/gates
      onDone();
    });

    act.appendChild(btn);
    card.appendChild(act);
    missionChoicesEl.appendChild(card);
  }
}

function escapeHtml(s) {
  return String(s)
    .replaceAll("&","&amp;")
    .replaceAll("<","&lt;")
    .replaceAll(">","&gt;")
    .replaceAll('"',"&quot;")
    .replaceAll("'","&#039;");
}

// ---------------------------
// Competition simulation (MVP)
// ---------------------------
function compGateOK(state, comp) {
  const g = comp.gates || {};
  if ((g.min_reputation ?? 0) > state.team.reputation) return {ok:false, reason:`Needs reputation ≥ ${g.min_reputation}`};
  if ((g.min_team_size ?? 0) > state.team_size) return {ok:false, reason:`Needs team size ≥ ${g.min_team_size}`};
  if (Array.isArray(g.requires_flag_any) && g.requires_flag_any.length > 0 && !hasAnyFlags(state, g.requires_flag_any)) {
    return {ok:false, reason:`Needs one of flags: ${g.requires_flag_any.join(", ")}`};
  }
  return {ok:true, reason:"OK"};
}

function baseCriteria(state) {
  // Map team signals into 0..10 baseline scores (simple but meaningful).
  const rep = state.team.reputation;
  const bud = state.team.budget;
  const mor = state.team.morale;
  const coh = state.team.cohesion;
  const fat = state.team.fatigue;
  const hrs = state.team.available_hours;
  const risk = state.team.risk;
  const ready = state.team.readiness;
  const wfb = state.team.workflow_bonus;

  const rnd = (a,b) => (Math.random()*(b-a)+a);

  const taste = clamp(5 + ready/3 + mor/40 - fat/50 + rnd(-1.2,1.2), 0, 10);
  const technique = clamp(5 + rep/20 + ready/4 + rnd(-1.1,1.1), 0, 10);
  const workflow = clamp(5 + coh/30 + wfb/4 - fat/70 + rnd(-1.2,1.2), 0, 10);
  const hygiene = clamp(5 + (100-fat)/60 + rnd(-1.0,1.0), 0, 10);
  const presentation = clamp(5 + rep/25 + ready/6 + rnd(-1.3,1.3), 0, 10);
  const timing = clamp(5 + (hrs-6)/3 + coh/80 - fat/60 + rnd(-1.3,1.3), 0, 10);

  return { taste, technique, workflow, hygiene, presentation, timing };
}

function mergePenaltyTable(rubric, format) {
  // rubric.penalties: [{key, points}|{key,result:"DQ"}]
  const table = new Map();
  for (const p of (rubric.penalties || [])) table.set(p.key, p);
  for (const p of (format.penalty_overrides || [])) table.set(p.key, { key:p.key, points:p.points });
  return table;
}

function resolveCompetition(state, compId) {
  const comp = DATA.catalog.competitions.find(c => c.id === compId);
  if (!comp) return { ok:false, message:`Competition not found: ${compId}` };

  const gate = compGateOK(state, comp);
  if (!gate.ok) return { ok:false, message:`Not eligible: ${gate.reason}` };

  const format = DATA.formats.formats.find(f => f.id === comp.format_id);
  const profile = DATA.profiles.rubric_profiles.find(p => p.id === comp.rubric_profile_id);
  const rubric = DATA.rubric; // standard only for MVP
  const routeBias = DATA.country.rubric_bias || {};

  const base = baseCriteria(state);

  // Apply multipliers (routeBias * profile * format) per criterion, cap to 10
  const profileMult = profile?.criteria_multipliers || {};
  const formatMult = format?.format_multipliers || {};
  const adjusted = {};
  const critDetail = {};

  for (const c of rubric.criteria) {
    const k = c.key;
    const b = base[k] ?? 5;
    const m = (routeBias[k] ?? 1) * (profileMult[k] ?? 1) * (formatMult[k] ?? 1);
    const a = clamp(b * m, 0, 10);
    adjusted[k] = a;
    critDetail[k] = { base: Number(b.toFixed(2)), mult: Number(m.toFixed(3)), adjusted: Number(a.toFixed(2)), weight: c.weight };
  }

  // Compute weighted score 0..100
  let score10 = 0;
  for (const c of rubric.criteria) score10 += adjusted[c.key] * c.weight;
  let score100 = score10 * 10;

  // Variance for team formats: low cohesion increases mistakes
  const cohesion = state.team.cohesion;
  const variance = clamp((50 - cohesion) / 50, 0, 0.6); // 0..0.6
  score100 = clamp(score100 + (Math.random()*10 - 5) * variance, 0, 100);

  // Penalties
  const penalties = [];
  const penaltyTable = mergePenaltyTable(rubric, format);

  const timingA = adjusted.timing ?? 5;
  const hygieneA = adjusted.hygiene ?? 5;
  const risk = state.team.risk;
  const fat = state.team.fatigue;

  // late plating: more likely if timing low, risk/fatigue high
  const lateChance = clamp(0.08 + (risk/60) + (fat/180) + ((5 - timingA)/20), 0.02, 0.60);
  if (Math.random() < lateChance) penalties.push("late_plating");

  // hygiene fault: DQ chance if hygiene low + risk high
  const dqChance = clamp(0.01 + (risk/120) + ((5 - hygieneA)/40), 0.0, 0.25);
  if (Math.random() < dqChance) penalties.push("cross_contamination");

  // format-specific common faults
  if (format?.id === "team_relay") {
    const handoffChance = clamp(0.10 + (risk/80) + ((55 - cohesion)/80), 0.02, 0.55);
    if (Math.random() < handoffChance) penalties.push("handoff_error");
  }
  if (format?.id === "solo_mystery_box") {
    const missChance = clamp(0.12 + (risk/90) + ((5 - (adjusted.workflow ?? 5))/30), 0.03, 0.55);
    if (Math.random() < missChance) penalties.push("missing_element");
  }
  if (format?.id === "team_cold_display") {
    const finishChance = clamp(0.10 + (risk/100) + ((5 - (adjusted.presentation ?? 5))/25), 0.03, 0.45);
    if (Math.random() < finishChance) penalties.push("finish_fault");
  }
  if (format?.id === "pastry_showpiece") {
    const structChance = clamp(0.06 + (risk/120) + (fat/250) + ((5 - (adjusted.technique ?? 5))/35), 0.01, 0.35);
    if (Math.random() < structChance) penalties.push("structure_failure");
  }

  // Apply penalties
  let dq = false;
  let penaltyPoints = 0;
  const applied = [];
  for (const key of penalties) {
    const def = penaltyTable.get(key);
    if (!def) continue;
    if (def.result === "DQ") {
      dq = true;
      applied.push({ key, result:"DQ" });
      break;
    }
    if (typeof def.points === "number") {
      penaltyPoints += def.points;
      applied.push({ key, points:def.points });
    }
  }

  if (dq) {
    score100 = 0;
  } else {
    score100 = clamp(score100 + penaltyPoints, 0, 100);
  }

  // Determine outcome bucket
  let outcome = "participation";
  if (dq) outcome = "DQ";
  else if (score100 >= 80) outcome = "WIN";
  else if (score100 >= 70) outcome = "PODIUM";
  else if (score100 >= 60) outcome = "PASS";

  // Apply stakes (simple)
  const stakes = comp.stakes || {};
  const repWin = stakes.reputation_gain_win ?? 0;
  const budWin = stakes.budget_gain_win ?? 0;

  let repDelta = 0;
  let budDelta = 0;

  if (outcome === "WIN") { repDelta = repWin; budDelta = budWin; }
  else if (outcome === "PODIUM") { repDelta = Math.max(1, Math.floor(repWin * 0.6)); budDelta = Math.floor(budWin * 0.5); }
  else if (outcome === "PASS") { repDelta = Math.max(0, Math.floor(repWin * 0.3)); budDelta = Math.floor(budWin * 0.2); }
  else if (outcome === "DQ") { repDelta = -Math.max(1, Math.floor(repWin * 0.5)); budDelta = 0; }

  state.team.reputation = Math.max(0, state.team.reputation + repDelta);
  state.team.budget = Math.max(0, state.team.budget + budDelta);

  // After comp day: fatigue rises, morale reacts
  const fatGain = clamp(10 + (format?.time_limit_minutes ?? 60) / 40, 8, 25);
  state.team.fatigue = clamp(state.team.fatigue + fatGain, 0, 100);
  if (outcome === "WIN") state.team.morale = clamp(state.team.morale + 6, 0, 100);
  if (outcome === "PODIUM") state.team.morale = clamp(state.team.morale + 3, 0, 100);
  if (outcome === "PASS") state.team.morale = clamp(state.team.morale + 1, 0, 100);
  if (outcome === "DQ") state.team.morale = clamp(state.team.morale - 8, 0, 100);

  // Circuit flags: if this comp is a stage, award on-win flags
  if (outcome === "WIN") {
    for (const circuit of (DATA.circuits.circuits || [])) {
      for (const stage of (circuit.stages || [])) {
        if (stage.competition_id === comp.id) {
          for (const f of (stage.on_win_set_flags || [])) state.flags.add(f);
        }
      }
    }
  }

  // Mark week progression (optional): if comp has suggestion, push week forward
  const ws = comp.week_suggestion;
  if (typeof ws === "number") state.week = Math.max(state.week, ws + 1);

  return {
    ok: true,
    comp: { id: comp.id, name: comp.name, type: comp.type, format: format?.name, profile: profile?.name },
    gate,
    score: Number(score100.toFixed(1)),
    outcome,
    repDelta,
    budDelta,
    penalties: applied,
    criteria: critDetail,
    variance: Number(variance.toFixed(2))
  };
}

function refreshCompetitionList() {
  if (!compSelectEl || !DATA) return;

  // read team size input
  if (teamSizeEl) {
    const n = Number(teamSizeEl.value || 4);
    STATE.team_size = clamp(isFinite(n) ? n : 4, 1, 12);
    teamSizeEl.value = String(STATE.team_size);
  }

  compSelectEl.innerHTML = "";
  const comps = DATA.catalog.competitions.slice().sort((a,b) => (a.week_suggestion ?? 999) - (b.week_suggestion ?? 999));

  const eligible = [];
  const ineligible = [];

  for (const c of comps) {
    const gate = compGateOK(STATE, c);
    (gate.ok ? eligible : ineligible).push({c, gate});
  }

  // eligible first
  for (const {c, gate} of eligible) {
    const opt = document.createElement("option");
    opt.value = c.id;
    opt.textContent = `✅ ${c.name} (${c.type})`;
    compSelectEl.appendChild(opt);
  }

  // separator
  if (eligible.length && ineligible.length) {
    const opt = document.createElement("option");
    opt.disabled = true;
    opt.textContent = "──────── Ineligible (requirements not met) ────────";
    compSelectEl.appendChild(opt);
  }

  for (const {c, gate} of ineligible) {
    const opt = document.createElement("option");
    opt.value = c.id;
    opt.textContent = `🔒 ${c.name} — ${gate.reason}`;
    compSelectEl.appendChild(opt);
  }

  // default selection
  if (eligible.length) compSelectEl.value = eligible[0].c.id;
}

// ---------------------------
// Loader + game loop
// ---------------------------
let DATA = null;
let STATE = defaultState();

async function loadAll(routeId) {
  const country = await loadJSON(`./data/countries/${routeId}.json`);
  const circuits = await loadJSON(`./data/circuits/circuits.json`);
  const formats = await loadJSON(`./data/competitions/formats.json`);
  const profiles = await loadJSON(`./data/competitions/profiles.json`);
  const catalog = await loadJSON(`./data/competitions/catalog.json`);
  const roles = await loadJSON(`./data/roles/roles.json`);
  const training = await loadJSON(`./data/training/sessions.json`);
  const season = await loadJSON(`./data/seasons/2026_open_calendar.json`);
  const rubric = await loadJSON(`./data/rubrics/standard_rubric.json`);

  const missionIds = country.content?.missions || [];
  const missions = [];
  for (const id of missionIds) {
    try {
      missions.push(await loadJSON(`./data/missions/${routeId}/${id}.json`));
    } catch (e) {
      console.warn("Missing mission file:", routeId, id, e);
    }
  }
  missions.sort((a,b) => (a.week - b.week) || String(a.id).localeCompare(String(b.id)));

  return { country, circuits, formats, profiles, catalog, roles, training, season, rubric, missions };
}

function nextAvailableMission(state, missions) {
  const done = new Set(state.completedMissions);
  const avail = missions.filter(m => !done.has(m.id) && isMissionAvailable(state, m));
  if (avail.length === 0) return null;
  avail.sort((a,b) => (a.week - b.week));
  return avail[0];
}

function runLoop() {
  if (!DATA) return;
  const mission = nextAvailableMission(STATE, DATA.missions);

  if (!mission) {
    missionMetaEl.textContent = "No available missions right now.";
    missionIntroEl.innerHTML = `<p class="hint">You can simulate a competition below, or add more missions.</p>`;
    missionChoicesEl.innerHTML = "";
    return;
  }

  renderMission(STATE, mission, () => {
    runLoop();
  });
}

function renderLoadedSummary() {
  dataOutEl.textContent = JSON.stringify({
    route: DATA.country?.id,
    missions_loaded: DATA.missions?.length,
    circuits: DATA.circuits?.circuits?.length,
    competitions: DATA.catalog?.competitions?.length,
    formats: DATA.formats?.formats?.length,
    profiles: DATA.profiles?.rubric_profiles?.length,
    roles: DATA.roles?.roles?.length,
    training_sessions: DATA.training?.sessions?.length,
    season: DATA.season?.id,
    rubric: DATA.rubric?.id
  }, null, 2);
}

// ---------------------------
// UI wiring
// ---------------------------
function mountRoutes() {
  routesEl.innerHTML = "";
  for (const r of ROUTES) {
    routesEl.appendChild(createButton(r, async () => {
      await startRoute(r);
    }));
  }
}

async function startRoute(routeId) {
  showResult("", "Loading data...");
  showComp("", "", null);

  STATE = defaultState();
  STATE.routeId = routeId;
  renderState(STATE);

  DATA = await loadAll(routeId);
  renderLoadedSummary();
  showResult("good", `Loaded route ${routeId}. Start playing from Week ${STATE.week}.`);
  refreshCompetitionList();
  runLoop();
}

btnReset.addEventListener("click", () => {
  startRoute(STATE.routeId).catch(err => showResult("bad", err.message));
});

btnSeason.addEventListener("click", () => {
  if (!DATA) return;
  dataOutEl.textContent = JSON.stringify(DATA.season, null, 2);
});
btnCatalog.addEventListener("click", () => {
  if (!DATA) return;
  dataOutEl.textContent = JSON.stringify(DATA.catalog, null, 2);
});
btnRoles.addEventListener("click", () => {
  if (!DATA) return;
  dataOutEl.textContent = JSON.stringify(DATA.roles, null, 2);
});
btnTraining.addEventListener("click", () => {
  if (!DATA) return;
  dataOutEl.textContent = JSON.stringify(DATA.training, null, 2);
});

// Competition UI listeners
if (teamSizeEl) {
  teamSizeEl.addEventListener("change", () => {
    refreshCompetitionList();
    renderState(STATE);
  });
}
if (btnRefreshCompsEl) {
  btnRefreshCompsEl.addEventListener("click", () => {
    refreshCompetitionList();
    showComp("good", "Competition list refreshed.", null);
  });
}
if (btnSimulateEl) {
  btnSimulateEl.addEventListener("click", () => {
    if (!DATA) return;
    const compId = compSelectEl?.value;
    if (!compId) return;

    // update team size from input
    if (teamSizeEl) {
      const n = Number(teamSizeEl.value || 4);
      STATE.team_size = clamp(isFinite(n) ? n : 4, 1, 12);
    }

    const res = resolveCompetition(STATE, compId);
    if (!res.ok) {
      showComp("bad", res.message, null);
      return;
    }

    const summary =
      `${res.outcome} • ${res.comp.name}\n` +
      `Score: ${res.score} / 100 (variance ${res.variance})\n` +
      `ΔRep: ${res.repDelta >= 0 ? "+" : ""}${res.repDelta} • ΔBudget: ${res.budDelta >= 0 ? "+" : ""}${res.budDelta}` +
      (res.penalties?.length ? `\nPenalties: ${res.penalties.map(p => p.key).join(", ")}` : "");

    showComp(res.outcome === "DQ" ? "bad" : "good", summary, res);
    renderState(STATE);
    refreshCompetitionList(); // flags may unlock comps
  });
}

// boot
mountRoutes();
startRoute("AU").catch(err => showResult("bad", err.message));
